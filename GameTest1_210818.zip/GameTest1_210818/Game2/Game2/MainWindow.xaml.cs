﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
namespace Game2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        System.Windows.Threading.DispatcherTimer theTimer;
        double Yvel = 2;
        double Xvel = 4;
        bool left ;
        bool right ;
        bool jump ;

        public MainWindow()
        {
            InitializeComponent();
            theTimer = new System.Windows.Threading.DispatcherTimer();
            theTimer.Interval = TimeSpan.FromMilliseconds(1);
            theTimer.IsEnabled = true;
            theTimer.Tick += dispatcherTimer_tick;
        }

        private void dispatcherTimer_tick(object sender, EventArgs e)
        {
            updatePlayer();
        }

        private void updatePlayer()
        {
            if (left.Equals("move"))
            {
                double nextX = Canvas.GetLeft(player) + Xvel;
                Canvas.SetLeft(player, nextX);
                if (nextX < 0 || nextX + player.ActualWidth > Canvas.ActualWidth && Xvel > 0)
                {
                    Xvel = 0;
                }
                right = false;
            }
            //double nextY = Canvas.GetTop(player) + Yvel;
            //Canvas.SetTop(player, nextY);
            //if (nextY < 0 || nextY + player.ActualHeight > Canvas.ActualHeight && Yvel > 0)
            //{
            //    Yvel = -Yvel;
            //}
        } 
        
        
        

        private void Canvas_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left:
                    left = true;
                    break;
                case Key.Right:
                    right = true;
                    break;
                case Key.Up:
                    jump = true;
                    break;
            }
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left:
                    left = true;
                    break;
                case Key.Right:
                    right = true;
                    break;
                case Key.Up:
                    jump = true;
                    break;
            }
        }
    }
}
