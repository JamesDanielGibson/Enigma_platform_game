﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Game4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        System.Windows.Threading.DispatcherTimer timer;
        Player player = new Player();
        Platform platform = new Platform();
       

        public MainWindow()
        {
            InitializeComponent();
           
            timer = new System.Windows.Threading.DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(16);
            timer.IsEnabled = true;
            timer.Tick += dispatcherTimer_Tick;

        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            updatePlayer();
        }

        private  void updatePlayer()
        {
            if(movingLeft)
            {
                MainCanvas.SetValue(sprite, MainCanvas.GetLeft(sprite));
            }
        }
    }
}
