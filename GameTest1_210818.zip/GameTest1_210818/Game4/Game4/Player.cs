﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game4
{
    public partial class Player : MainWindow
    {
        double xVel = 4;
        double yVel = 2;
        bool movingLeft;
        bool movingRight;
        bool jumping;
        double f = 4;
        double g = 0;

        public void initialise()
        {
           
        }
        public  void update(System.Windows.MessageBoxImage n)
        {
            double nextX = MainCanvas.GetLeft(sprite) + xVel;
        }
    }
}
