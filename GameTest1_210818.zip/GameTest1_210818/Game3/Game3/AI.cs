﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game3
{
    class AI
    {
        /*
         *  0 | 1 | 2   00|01|02
         *  ----------  10|11|12
         *  3 | 4 | 5   20|21|22
         *  ----------
         *  6 | 7 | 8
         */
        private string tileRef;

        public void play()
        {
            MarkType[] ArrRes = MainWindow.ResultList;
            makeList(ArrRes);
           // setPlayer1Turn();
        }

        private void makeList(MarkType[] plays)
        {
            List<int> open = new List<int>();
            for(int x = 0; x<plays.Length;x++)
            {
                if(plays[x] == MarkType.Free)
                {
                    open.Add(x);
                }
            }
            ConToRowCol(open);
        }

        private void ConToRowCol(List<int> l)
        {
            List<string> open = new List<string>();
            foreach(int x in l)
            {
                if (x == 0)
                    open.Add("00");
                if (x == 1)
                    open.Add("01");
                if (x == 2)
                    open.Add("02");

                if (x == 3)
                    open.Add("10");
                if (x == 4)
                    open.Add("11");
                if (x == 5)
                    open.Add("12");

                if (x == 6)
                    open.Add("20");
                if (x == 7)
                    open.Add("21");
                if (x == 7)
                    open.Add("22");
            }
            checker(open);
        }
        private void conToEnum(string str)
        {
            if (str.Equals("00"))
                MainWindow.ResultList[0] = MarkType.Nought;
            if (str.Equals("01"))
                MainWindow.ResultList[1] = MarkType.Nought;
            if (str.Equals("02"))
                MainWindow.ResultList[2] = MarkType.Nought;
            if (str.Equals("10"))
                MainWindow.ResultList[3] = MarkType.Nought;
            if (str.Equals("11"))
                MainWindow.ResultList[4] = MarkType.Nought;
            if (str.Equals("12"))
                MainWindow.ResultList[5] = MarkType.Nought;
            if (str.Equals("20"))
                MainWindow.ResultList[6] = MarkType.Nought;
            if (str.Equals("21"))
                MainWindow.ResultList[7] = MarkType.Nought;
            if (str.Equals("22"))
                MainWindow.ResultList[8] = MarkType.Nought;
        }
        public void setPlayer1Turn()
        {
            MainWindow.turn = true;
        }
        private void checker(List<string> l)
        {
            MarkType[] arr = new MarkType[9];
            arr = MainWindow.ResultList;
            int ans =-1;
            for(int j = 0; j <2; j++)
            {
                ans = checkCol(j, arr);
            }
            if(ans >-1)
            {
                conToEnum(l[ans]);
                tileRef = l[ans];
            }
           // else
           // {
                for (int j = 0; j < 9; j += 3)
                {
                    ans = checkRow(j, arr);
                }
                if (ans > -1)
                {
                    conToEnum(l[ans]);
                    tileRef = l[ans];
                }
                else
                {
                    Random rnd = new Random();
                    int i = rnd.Next(0, l.Count);
                    conToEnum(l[i]);
                    tileRef = l[i];
              //  }
            }
           
            //__________________________________________________________

           
            
        }
        private int checkRow(int row, MarkType[] arr)
        {
            if(arr[row] == MarkType.Free || arr[row+1] == MarkType.Free || arr[row+2]== MarkType.Free)
            {
                if(arr[row]==MarkType.Free && arr[row+1]==MarkType.Cross && arr[row+2]==MarkType.Cross)
                {
                    return (row + 0);
                }
                if (arr[row+1] == MarkType.Free && arr[row ] == MarkType.Cross && arr[row + 2] == MarkType.Cross)
                {
                    return (row + 1) ;
                }
                if (arr[row+2] == MarkType.Free && arr[row + 1] == MarkType.Cross && arr[row + 0] == MarkType.Cross)
                {
                    return (row + 2) ;
                }
            }
            return -1 ;
        }
        private int checkCol(int col, MarkType[] arr)
        {
            if (arr[col] == MarkType.Free || arr[col + 3] == MarkType.Free || arr[col + 6] == MarkType.Free)
            {
                if (arr[col] == MarkType.Free && arr[col + 3] == MarkType.Cross && arr[col + 6] == MarkType.Cross)
                {
                    return (col + 0) ;
                }
                if (arr[col + 3] == MarkType.Free && arr[col] == MarkType.Cross && arr[col + 6] == MarkType.Cross)
                {
                    return (col + 3) ;
                }
                if (arr[col + 6] == MarkType.Free && arr[col + 3] == MarkType.Cross && arr[col + 0] == MarkType.Cross)
                {
                    return (col + 6);
                }
            }
            return -1;
        }

        public string getRef()
        {
            return tileRef;
        }
    }
}
