﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Game3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Private members
        private static MarkType[] mResults;
        private static bool mPlayer1Turn;
        private static bool mGameEnd;
        AI player2 = new AI();
        #endregion

        #region Constructor

        public MainWindow()
        {
            InitializeComponent();

            NewGame();
        }

        #endregion
        public static bool turn
        {
            get { return mPlayer1Turn; }
            set { mPlayer1Turn = value; }
        }

        public static MarkType[] ResultList
        {
            get { return mResults; }
            set { mResults = value; }
        }

        private void NewGame()
        {
            
            mResults = new MarkType[9];

            for(int i =0;i<mResults.Length;i++)
            {
                mResults[i] = MarkType.Free;

                mPlayer1Turn = true;
                Container.Children.Cast<Button>().ToList().ForEach(button=>
                {
                    button.Content = string.Empty;
                    button.Background = Brushes.White;
                    button.Foreground = Brushes.DarkCyan;
                });

                mGameEnd = false;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(mGameEnd)
            {
                NewGame();
                return;
            }
            var button = (Button)sender;

            var Column = Grid.GetColumn(button);
            var row = Grid.GetRow(button);
            var index = Column+(row*3);
            if(mResults[index]!= MarkType.Free)
            {
                return;
            }

            mResults[index] = MarkType.Cross;
           
            button.Content = "X";
            
            player2.play();
            setO(player2.getRef());
                
            
            

            CheckForWinner();
        }
        #region checkers
        private void CheckForWinner()
        {
            //check for hoz wins
            var same = (mResults[0] & mResults[1] & mResults[2]) == mResults[0];
            if (mResults[0] != MarkType.Free && same)
            {
                mGameEnd = true;
                Button0_0.Background = Button0_1.Background = Button0_2.Background = Brushes.Aqua;
            }
            
            same = (mResults[3] & mResults[4] & mResults[5]) == mResults[3];
            if (mResults[3] != MarkType.Free && same)
            {
                mGameEnd = true;
                Button1_0.Background = Button1_1.Background = Button1_2.Background = Brushes.Aqua;
            }

            same = (mResults[6] & mResults[7] & mResults[8]) == mResults[6];
            if (mResults[6] != MarkType.Free && same)
            {
                mGameEnd = true;
                Button2_0.Background = Button2_1.Background = Button2_2.Background = Brushes.Aqua;
            }

            // vert check
             same = (mResults[0] & mResults[3] & mResults[6]) == mResults[0];
            if (mResults[0] != MarkType.Free && same)
            {
                mGameEnd = true;
                Button0_0.Background = Button1_0.Background = Button2_0.Background = Brushes.Aqua;
            }

            same = (mResults[1] & mResults[4] & mResults[7]) == mResults[1];
            if (mResults[1] != MarkType.Free && same)
            {
                mGameEnd = true;
                Button0_1.Background = Button1_1.Background = Button2_1.Background = Brushes.Aqua;
            }

            same = (mResults[2] & mResults[5] & mResults[8]) == mResults[2];
            if (mResults[2] != MarkType.Free && same)
            {
                mGameEnd = true;
                Button0_2.Background = Button1_2.Background = Button2_2.Background = Brushes.Aqua;
            }

            //diag check
            same = (mResults[0] & mResults[4] & mResults[8]) == mResults[0];
            if (mResults[0] != MarkType.Free && same)
            {
                mGameEnd = true;
                Button0_0.Background = Button1_1.Background = Button2_2.Background = Brushes.Aqua;
            }

            same = (mResults[2] & mResults[4] & mResults[6]) == mResults[2];
            if (mResults[2] != MarkType.Free && same)
            {
                mGameEnd = true;
                Button0_2.Background = Button1_1.Background = Button2_0.Background = Brushes.Aqua;
            }



            if (!mResults.Any(result=>result == MarkType.Free))
            {
                mGameEnd = true;

                Container.Children.Cast<Button>().ToList().ForEach(button =>
                {
                    
                    button.Foreground = Brushes.Coral;
                });
            }
        }
        #endregion

        public void setO(string tileRef)
        {
            //row column
            if(tileRef.Equals("00"))
                Button0_0.Content = "O";

            if (tileRef.Equals("01"))
                Button0_1.Content = "O";

            if (tileRef.Equals("02"))
                Button0_2.Content = "O";

            if (tileRef.Equals("10"))
                Button1_0.Content = "O";

            if (tileRef.Equals("11"))
                Button1_1.Content = "O";

            if (tileRef.Equals("12"))
                Button1_2.Content = "O";

            if (tileRef.Equals("20"))
                Button2_0.Content = "O";

            if (tileRef.Equals("21"))
                Button2_1.Content = "O";

            if (tileRef.Equals("22"))
                Button2_1.Content = "O";


        }
    }
}
